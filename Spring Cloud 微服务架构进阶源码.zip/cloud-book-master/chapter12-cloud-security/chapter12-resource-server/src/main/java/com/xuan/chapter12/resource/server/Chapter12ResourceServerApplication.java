package com.xuan.chapter12.resource.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chapter12ResourceServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(Chapter12ResourceServerApplication.class, args);
    }
}
