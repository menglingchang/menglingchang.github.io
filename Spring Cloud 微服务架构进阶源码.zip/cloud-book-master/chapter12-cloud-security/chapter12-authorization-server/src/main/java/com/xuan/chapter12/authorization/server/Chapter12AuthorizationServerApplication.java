package com.xuan.chapter12.authorization.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chapter12AuthorizationServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(Chapter12AuthorizationServerApplication.class, args);
    }
}
