package com.blueskykong.chapter11.config.client;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chapter11ConfigClientApplication {

    public static void main(String[] args) {
        SpringApplication.run(Chapter11ConfigClientApplication.class, args);
    }
}
