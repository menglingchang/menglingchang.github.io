package com.blueskykong.chapter11.config.client2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chapter11ConfigClient2Application {

    public static void main(String[] args) {
        SpringApplication.run(Chapter11ConfigClient2Application.class, args);
    }
}
