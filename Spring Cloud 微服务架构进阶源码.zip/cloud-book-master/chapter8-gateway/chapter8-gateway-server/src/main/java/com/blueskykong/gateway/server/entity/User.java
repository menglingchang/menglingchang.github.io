package com.blueskykong.gateway.server.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author keets
 * @data 2018/5/20.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {
    private String key;
}
