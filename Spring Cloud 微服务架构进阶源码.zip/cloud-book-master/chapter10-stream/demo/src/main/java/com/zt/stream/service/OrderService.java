package com.zt.stream.service;

import com.zt.stream.beans.Order;
import org.springframework.stereotype.Service;

@Service
public class OrderService {
    public void handle(Order order) {

    }
}
