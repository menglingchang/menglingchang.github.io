package com.zt.stream.beans;

public class Vote {
}
