# spring-cloud-stream-binder-rabbit
Spring Cloud Stream Binder implementation for Rabbit
