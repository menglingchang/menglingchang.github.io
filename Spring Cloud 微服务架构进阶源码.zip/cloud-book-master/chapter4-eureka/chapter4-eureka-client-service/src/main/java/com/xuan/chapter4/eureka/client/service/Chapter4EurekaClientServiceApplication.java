package com.xuan.chapter4.eureka.client.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Chapter4EurekaClientServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(Chapter4EurekaClientServiceApplication.class, args);
    }
}
