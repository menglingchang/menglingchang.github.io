## 本级代码清单只有一个
ch14-1-consul-register 演示服务启动时自定义的一些配置